// Module dependencies

var express    = require('express'),
    mysql      = require('mysql');
	bodyParser = require('body-parser');
// Application initialization

var connection = mysql.createConnection({
    host:"localhost",
	user:"root",
	password:"koyel",
	database:"nodetest"
    });
    
var app = express();

// Configuration

app.use(bodyParser.urlencoded({ extended: true}));

// Main route sends our HTML file

app.get('/', function(req, res,next) {
    res.sendfile('Delete.html');
});

// Delete Record from MySQL database

app.post('/mydelete', function (req, res) {
    connection.query("delete  from student where rtrim(ltrim(name))='"+req.body.t1+"'", 
        function (err, result) {
            if (err) throw err;
            res.send('Record deleted for ' + req.body.t1 + '  successfully');
			console.log("Number of records deleted: " + result.affectedRows);
        }
    );
});

// Begin listening

app.listen(3000);
console.log("This app is listening at port :3000");