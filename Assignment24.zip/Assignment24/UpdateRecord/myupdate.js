// Module dependencies

var express    = require('express'),
    mysql      = require('mysql');
	bodyParser = require('body-parser');
// Application initialization

var connection = mysql.createConnection({
    host:"localhost",
	user:"root",
	password:"koyel",
	database:"nodetest"
    });
    
var app = express();

// Configuration

app.use(bodyParser.urlencoded({ extended: true}));

// Main route sends our HTML file

app.get('/', function(req, res,next) {
    res.sendfile('Update.html');
});

// Update Record from MySQL database

app.post('/myupdate', function (req, res) {
    connection.query("update student set email='"+req.body.t2+"',Comments='"+req.body.t3+"' where rtrim(ltrim(name))='"+req.body.t1+"'", 
        function (err, result) {
            if (err) throw err;
            res.send('Record updated for ' + req.body.t1 + '  successfully');
			console.log("Number of records updated: " + result.affectedRows);
        }
    );
});

// Begin listening

app.listen(3000);
console.log("This app is listening at port :3000");