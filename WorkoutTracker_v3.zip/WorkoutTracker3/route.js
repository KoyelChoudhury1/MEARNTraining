///// required modules 

// var express = require('express')
// var app = express()
// var mysql = require('mysql');
// var bodyParser = require('body-parser');
// app.use(bodyParser.urlencoded({ extended: true}));

// SHOW LIST OF CATEGORY
// app.get('/', function(req, res, next) {
// 	req.getConnection(function(error, conn) {
// 		conn.query('SELECT * FROM workout_category ORDER BY id DESC',function(err, rows, fields) {
// 			//if(err) throw err
// 			if (err) {
// 				req.flash('error', err)
				
// 			} else {
// 				//console.log(rows)
// 				res.end(JSON.stringify(rows));
// 			}
// 		})
// 	})
// })
// module.exports = app