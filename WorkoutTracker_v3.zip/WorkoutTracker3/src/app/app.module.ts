import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import {HttpClientModule, HttpClient} from '@angular/common/http';
// import { HttpService } from './http.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {HttpModule} from '@angular/http';


import { AppComponent } from './app.component';
import { WorkoutComponent } from './workout/workout.component';
import { CategoryComponent } from './category/category.component';
import { TrackComponent } from './track/track.component';

import {RouterModule,Routes} from '@angular/router';
import { CreateComponent } from './create/create.component';
import { ModalComponent } from './modal/modal.component';
import { AlertsComponent } from './alerts/alerts.component';

const appRouters:Routes=[
{ path:'View',component:WorkoutComponent},
{ path:'Create',component: CreateComponent},
{ path:'Category',component:CategoryComponent},
{ path:'Track',component:TrackComponent},


];


@NgModule({
  declarations: [
    AppComponent,
    WorkoutComponent,
    CategoryComponent,
    TrackComponent,
    CreateComponent,
    ModalComponent,
    AlertsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRouters), 
    HttpModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
