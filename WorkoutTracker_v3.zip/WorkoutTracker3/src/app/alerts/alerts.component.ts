import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alerts',
  template: `
  <div class="alert-box" [ngClass]="{'drop-shadow': show}">
    <div class="alert-message alert-{{type}}" *ngIf="show">
      <strong>{{message}}</strong>
    </div>
  </div>
`,
  styleUrls: ['./alerts.component.css']
})
export class AlertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
