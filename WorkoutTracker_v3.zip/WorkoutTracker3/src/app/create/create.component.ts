// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { HttpService } from '../http.service';
// import { AlertService } from '../alerts/alerts.service';
// import {HttpClientModule, HttpClient} from '@angular/common/http';


import { Component, OnInit, group, Input, Output } from '@angular/core';
// import { HttpService } from '../http.service';
import { Create } from '../create/create';
import {Observable} from "rxjs/Observable";
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { NgModule, Directive} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { AppModule } from '../app.module';
import {RouterModule,Router,Routes,ActivatedRoute} from "@angular/router";


import { FormsModule } from '@angular/forms';
import { WorkoutComponent } from '../workout/workout.component';



@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {



  ngOnInit() {
  }


}
