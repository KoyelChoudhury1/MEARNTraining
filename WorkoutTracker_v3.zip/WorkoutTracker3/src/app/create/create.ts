export interface Create {
    title: string;
    note: string;
    calories: number;
    category: string;
}