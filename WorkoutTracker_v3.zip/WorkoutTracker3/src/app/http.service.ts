import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Create } from './create/create';
import {Http, Headers, RequestOptions, Response} from '@angular/http';
import 'rxjs/add/operator/map'; 
import {Observable} from "rxjs/Observable";
import { FormControl, FormGroup, Validators } from '@angular/forms';
// import { Resolve } from '@angular/router/src/interfaces';



const SUCCESS = true;
const ERROR = false;

@Injectable()
export class HttpService {

  createWorkout: any;
    constructor(private httpClient: HttpClient) {}

    getCategories(): Array<string> {
        let categories = new Array<string>();
        const existingCategories = localStorage.getItem('categories');
        if(null !== existingCategories) {
            categories = JSON.parse(existingCategories);
        }
        return categories;
    }

    saveCategory(category: string): boolean {
        let categories = this.getCategories();
        if(categories.indexOf(category) === -1) {
            categories.push(category);
            localStorage.setItem('categories', JSON.stringify(categories));
            return SUCCESS
        } else {
            return ERROR;
        }
    }
    
    updateCategory(category: string, idx: number): boolean {
        let categories = this.getCategories();
        categories[idx] = category;
        localStorage.setItem('categories', JSON.stringify(categories));
        return SUCCESS;
    }

    deleteCategory(idx: number): boolean {
        let categories = this.getCategories();
        categories.splice(idx, 1);
        localStorage.setItem('categories', JSON.stringify(categories));
        return SUCCESS;
    }

    



}

