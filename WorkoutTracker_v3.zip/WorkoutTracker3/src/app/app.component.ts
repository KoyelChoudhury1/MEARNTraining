import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  // template: `WORKOUT TRACKER
  // <a [routerLink]="['/View']">ViewAll</a>
  // <a [routerLink]="['/Create']">Create</a>
  // <a [routerLink]="['/Category']">Category</a>
  // <a [routerLink]="['/Track']">Track</a>
  // <router-outlet></router-outlet>
  // `
})
export class AppComponent {
  title = 'app';
}
