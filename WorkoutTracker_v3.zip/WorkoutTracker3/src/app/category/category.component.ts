import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { AlertService } from '../alerts/alerts.service';
import { Http } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Create } from '../create/create';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})

// export class CategoryComponent implements OnInit {
  

//   constructor( ) { 
    
//   }

//   ngOnInit() {
//   }

// }
//---------------------------------------------------------
export class CategoryComponent{

  __HttpService: any;
  create: Create;
  id: number;
  category: string;
  
 

  constructor(
    
    // private __httpService: Http.service,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    
   }

  //// adding new employee
  addCategory() {
    const newCategory ={
      category: this.category,
      
    }

      this.__HttpService.addCategory()(newCategory).subscribe(
        data => {
          
        },
        error => {
          console.error("Error adding employee!");
          return Observable.throw(error);
        }
      );
    
    this.router.navigate(['/employees'])
  }


  ngOnInit() {

    var id = this.route.params.subscribe(params => {
      var id = params['id'];
      this.category = id ? 'Edit Category' : 'New Category';

    });
  }

}
