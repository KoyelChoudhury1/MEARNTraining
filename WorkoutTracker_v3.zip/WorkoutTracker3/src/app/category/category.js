import config from '../../../config';

var express = require('express');

// var app = express();
// var mysql = require('mysql');
// var bodyParser = require('body-parser');
// app.use(bodyParser.urlencoded({ extended: true}));
// //create connection with mysql database-workout
// var con = mysql.createConnection({
// host:"localhost",
// user:"root",
// password:"koyel",
// database:"workout"
// });
// app.get('/',function(req,res,next)
// {
// res.sendfile('category.component.html');
// });
// app.post('app-alerts',function(req,res)
// {
// // console.log(req.body);
// res.write('Category " '+req.body.t1+ ' " .\n');

// res.end();
// res.end();
// con.query("insert into workout_category(category_name) values (' "+req.body.t1+" ')", function(err,result)
// {
// if(err)
// throw err;
// });
// });
