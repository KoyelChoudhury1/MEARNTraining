var xy={}
xy.add=function(a,b)
{
console.log('Addition : '+(a+b));
}
xy.sub=function(a,b)
{
console.log('Subtraction : '+(a-b));
}
xy.mul=function(a,b)
{
console.log('Multiplication : '+(a*b));
}
xy.div=function(a,b)
{
console.log('Division : '+(a+b));
}
exports.data=xy;