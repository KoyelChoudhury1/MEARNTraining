var res=require('./calculator.js');
//res.data.welcome();
//res.data.Hi();
//res.data.nodejs();
console.log('Welcome to Calculator ');
res.data.add(5,6);
res.data.sub(5,6);
res.data.mul(5,6);
res.data.div(5,6);
