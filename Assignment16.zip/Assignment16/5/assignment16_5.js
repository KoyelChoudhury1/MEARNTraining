var http=require('http');

var Product=[
{ProductID:001, Name:"Laptop"},
{ProductID:002, Name:"Tablet"},
{ProductID:003, Name:"Mobile"},
{ProductID:004, Name:"Desktop"},
{ProductID:005, Name:"Router"},
{ProductID:006, Name:"Headphones"},
{ProductID:007, Name:"Mouse"}];

var ser=http.createServer(function(req,res)
{
res.writeHead(200,{'Content-Type':'application-json'});
res.end(JSON.stringify(Product));
});
ser.listen(5050);

console.log('server started on 5050');
