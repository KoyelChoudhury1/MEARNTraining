var fs=require("fs");
var data=fs.readFileSync('test.txt');
var writeStream = fs.createWriteStream("DuplicateTest.txt");
writeStream.write(data);
writeStream.end();
console.log("File copied successfully");