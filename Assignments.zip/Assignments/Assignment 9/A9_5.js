//Arithmetic functions for multiplication and division for two numbers
//Function for product of two numbers
function Mul()
{
	 F1 = document.getElementById("num1").value;
    F2 = document.getElementById("num2").value;
	document.getElementById("result").innerHTML=F1*F2;
}
//Function for division of two numbers
function Divide()
{
	 F1 = document.getElementById("num1").value;
    F2 = document.getElementById("num2").value;
	document.getElementById("result").innerHTML=F1/F2;
}