var express = require('express');
var app = express();
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true}));
//create connection with mysql database-nodetest
var con = mysql.createConnection({
host:"localhost",
user:"root",
password:"koyel",
database:"nodetest"
});
app.get('/',function(req,res,next)
{
res.sendfile('Create.html');
});
app.post('/myaction',function(req,res)
{
console.log(req.body);
res.write('Name is " '+req.body.t1+ ' " .\n');
res.write('Email is " '+req.body.t2+ ' " .\n');
res.write('Comments is " '+req.body.t3+ ' " .\n');
res.end();
res.end();
con.query("insert into student(name,email,Comments) values ('"+req.body.t1+"','"+req.body.t2+"','"+req.body.t3+"')", function(err,result)
{
if(err)
throw err;
});
});

app.listen(3000);
console.log("this app is listening at port :3000");