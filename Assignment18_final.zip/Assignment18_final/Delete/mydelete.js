/*var express = require('express');
var app = express();
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true}));
//Connection with mysql database-nodetest
var con = mysql.createConnection({
host:"localhost",
user:"root",
password:"koyel",
database:"nodetest"
});

//Delete Record
app.get('/delete',function(req,res,next)
{
res.sendfile('Delete.html');
});
app.post('/myaction',function(req,res)
{
//console.log(req.body);
//res.write(req.body.t1+":Record Deleted Successfully.\n");
con.connect(function(err)
{
if(err)throw err;
console.log("connect");
//var sql_d="delete student where name='"+req.body.t1+"';
console.log(req.body);
res.write(req.body.t1+":Record Deleted Successfully.\n");
con.query("delete  from student where rtrim(ltrim(name))='"+req.body.t1+"' ",function(err,result)
{
if(err) throw err;
console.log("row deleted");
});});});

app.listen(3000);
console.log("this app is listening at port :3000");*/

// Module dependencies

var express    = require('express'),
    mysql      = require('mysql');
	bodyParser = require('body-parser');
// Application initialization

var connection = mysql.createConnection({
    host:"localhost",
	user:"root",
	password:"koyel",
	database:"nodetest"
    });
    
var app = express();

// Configuration

app.use(bodyParser.urlencoded({ extended: true}));

// Main route sends our HTML file

app.get('/delete', function(req, res) {
    res.sendfile('Delete.html');
});

// Delete Record from MySQL database

app.post('/mydelete', function (req, res) {
    connection.query("delete  from student where rtrim(ltrim(name))='"+req.body.t1+"'", 
        function (err, result) {
            if (err) throw err;
            res.send('Record deleted for ' + req.body.t1 + '  successfully');
        }
    );
});

// Begin listening

app.listen(3000);
console.log("This app is listening at port :3000");